from django import forms

class TaskUpdateForm(forms.Form):
    completed = forms.BooleanField(required=False)
