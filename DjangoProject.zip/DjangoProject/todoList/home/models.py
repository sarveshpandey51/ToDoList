from django.db import models

# Create your models here.

class Task(models.Model):
    taskTitle = models.CharField(max_length=30)
    tasKDesc = models.TextField()
    time = models.DateTimeField(auto_now_add= True)
    completed = models.BooleanField(default=False)  # Add a completed field
    
    def __str__(self) -> str:
        return self.taskTitle