
from django.contrib import admin
from django.urls import path,include
from home import views
from django.contrib.auth import views as auth_views
# The urls are been called up from HTML  page from herf 
# name  is an optional argument that gives the URL pattern a name. 

urlpatterns = [
    path('', views.home, name='home'),
    path('tasks/', views.tasks, name='tasks'),
    path('save-task-status/', views.save_task_status, name='save_task_status'),  # New URL pattern
    path('login/', views.user_login, name= 'login'),
    path('logout/', views.user_logout, name='logout'),
    path('register/', views.register, name='register'),
]
