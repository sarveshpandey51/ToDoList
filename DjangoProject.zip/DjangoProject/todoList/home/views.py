from django.shortcuts import render, HttpResponse, redirect
from home.models import Task
from home.forms import TaskUpdateForm
from django.http import JsonResponse 
from django.views.decorators.csrf import csrf_exempt
import json
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required


# Index
def home(request):
    context = {'success': False}
    if request.method == "POST":
        title = request.POST['title']
        desc = request.POST['desc']
        print(title, desc)
        ins = Task(taskTitle =title, tasKDesc =desc)
        ins.save()
        context = {'success': True}
    return render(request, 'index.html', context)

# tasks 
def tasks(request):
    allTasks = Task.objects.all() #This variable stores all the objects of the query set.
    # print(allTasks)
    # for item in allTasks:
    #     print(item.tasKDesc)
    context = {'tasks': allTasks}
    return render(request, 'tasks.html', context)


# save tasks 
@csrf_exempt  # For simplicity, you can exempt CSRF protection here. In production, handle CSRF properly.
def save_task_status(request):
    if request.method == 'POST':
        task_ids = request.POST.getlist('task_ids')
        
        for task_id in task_ids:
            task = Task.objects.get(pk=task_id)
            task.completed = bool(request.POST.get(f'task_{task_id}'))
            task.save()
        
        return JsonResponse({'message': 'Task statuses saved successfully'})
    
    return JsonResponse({'message': 'Invalid request method'}, status=400)

# register 
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')  # Redirect to the home page after registration
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


# user login 
def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('home')  # Redirect to the home page after login
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

# log out 
def user_logout(request):
    logout(request)
    return redirect('home')  # Redirect to the home page after logout

# Create your views here.
